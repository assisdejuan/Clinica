class Paciente {
    String nome;
    int idade;
    boolean urgente;

    public Paciente(String nome, int idade, boolean urgente) {
        this.nome = nome;
        this.idade = idade;
        this.urgente = urgente;
    }

    @Override
    public String toString() {
        return nome + " (Idade: " + idade + ", " + (urgente ? "Urgente" : "Normal") + ")";
    }
}
