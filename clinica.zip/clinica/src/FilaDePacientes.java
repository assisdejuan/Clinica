import java.util.LinkedList;

public class FilaDePacientes {
    private LinkedList<Paciente> fila = new LinkedList<>();

    public void enqueue(Paciente paciente) {
        if (fila.isEmpty()) {
            fila.add(paciente);
            return;
        }

        int pos = 0;
        for (Paciente p : fila) {

            if (paciente.urgente && !p.urgente) {
                break;
            }

            if (paciente.urgente == p.urgente) {
                if (paciente.idade > p.idade) {
                    break;
                }
            }
            pos++;
        }
        fila.add(pos, paciente);
    }

    public Paciente dequeue() {
        if (fila.isEmpty()) {
            return null;
        }
        return fila.removeFirst();
    }

    public Paciente peek() {
        if (fila.isEmpty()) {
            return null;
        }
        return fila.getFirst();
    }

    public boolean isEmpty() {
        return fila.isEmpty();
    }

    public int tamanho() {
        return fila.size();
    }
}
