import java.util.ArrayList;
class ListaDeAtendidos {
    private ArrayList<Paciente> lista = new ArrayList<>();

    public void adicionarAtendido(Paciente paciente) {
        lista.add(paciente);
    }

    public void listarAtendidos() {
        if (lista.isEmpty()) {
            System.out.println("Nenhum paciente atendido ainda.");
            return;
        }
        System.out.println("Pacientes atendidos:");
        for (Paciente paciente : lista) {
            System.out.println("- " + paciente);
        }
    }

    public boolean pacienteAtendido(String nome) {
        for (Paciente paciente : lista) {
            if (paciente.nome.equalsIgnoreCase(nome)) {
                return true;
            }
        }
        return false;
    }

    public int totalAtendidos() {
        return lista.size();
    }

    public double mediaIdade() {
        if (lista.isEmpty()) return 0;
        int soma = 0;
        for (Paciente p : lista) {
            soma += p.idade;
        }
        return (double) soma / lista.size();
    }
}