import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final FilaDePacientes fila = new FilaDePacientes();
    private static final ListaDeAtendidos atendidos = new ListaDeAtendidos();

    private static final int MAX_PACIENTES = 5;
    private static boolean primeiraInsercaoFeita = false;

    public static void main(String[] args) {
        System.out.println(" === Bem vindo ao SUS ===");
        boolean running = true;

        while (running) {
            exibirMenu();
            int opcao = lerInteiro("Escolha uma opção: ");
            switch (opcao) {
                case 1 -> {
                    if (!primeiraInsercaoFeita) {
                        inserirPacientesLimitado(MAX_PACIENTES);
                        atenderPrimeiros(3);
                        mostrarProximoPaciente();
                        listarAtendidos();
                        primeiraInsercaoFeita = true;
                    } else {
                        System.out.println("Você já inseriu os 5 pacientes permitidos nesta execução.");
                    }
                }
                case 2 -> atenderPaciente();
                case 3 -> mostrarProximoPaciente();
                case 4 -> pesquisarPacienteAtendido();
                case 5 -> listarAtendidos();
                case 6 -> mostrarEstatisticas();
                case 7 -> {
                    System.out.println("Saindo do sistema. Até mais!");
                    running = false;
                }
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        }

        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\nMenu:");
        System.out.println("1 - Inserir até 5 pacientes");
        System.out.println("2 - Atender próximo paciente");
        System.out.println("3 - Consultar próximo paciente a ser atendido");
        System.out.println("4 - Pesquisar paciente atendido");
        System.out.println("5 - Listar todos os pacientes atendidos");
        System.out.println("6 - Mostrar relatório");
        System.out.println("7 - Sair");
    }

    private static void inserirPacientesLimitado(int quantidade) {
        System.out.println("\nInsira os dados de " + quantidade + " pacientes para a fila:");
        for (int i = 1; i <= quantidade; i++) {
            String nome = lerNomePaciente();
            int idade = lerIdadePaciente();
            boolean urgente = lerUrgenciaPaciente();
            Paciente paciente = new Paciente(nome, idade, urgente);
            fila.enqueue(paciente);
            System.out.println("Paciente " + paciente + " adicionado à fila.");
        }
    }

    private static void atenderPrimeiros(int quantidade) {
        System.out.println("\nAtendendo os " + quantidade + " primeiros pacientes da fila:");
        for (int i = 0; i < quantidade; i++) {
            Paciente paciente = fila.dequeue();
            if (paciente != null) {
                System.out.println("Atendendo: " + paciente);
                atendidos.adicionarAtendido(paciente);
            } else {
                System.out.println("Fila vazia, não há mais pacientes para atender.");
                break;
            }
        }
    }

    private static void atenderPaciente() {
        Paciente paciente = fila.dequeue();
        if (paciente == null) {
            System.out.println("Fila vazia. Não há pacientes para atender.");
        } else {
            System.out.println("Atendendo paciente: " + paciente);
            atendidos.adicionarAtendido(paciente);
        }
    }

    private static void mostrarProximoPaciente() {
        Paciente proximo = fila.peek();
        if (proximo == null) {
            System.out.println("Nenhum paciente na fila.");
        } else {
            System.out.println("Próximo paciente a ser atendido: " + proximo);
        }
    }

    private static void pesquisarPacienteAtendido() {
        System.out.print("Digite o nome do paciente a pesquisar: ");
        String nome = scanner.nextLine().trim();
        boolean encontrado = atendidos.pacienteAtendido(nome);
        if (encontrado) {
            System.out.println("Paciente " + nome + " já foi atendido.");
        } else {
            System.out.println("Paciente " + nome + " não foi atendido ainda.");
        }
    }

    private static void listarAtendidos() {
        System.out.println("\nLista de pacientes atendidos:");
        atendidos.listarAtendidos();
    }

    private static void mostrarEstatisticas() {
        System.out.println("\n--- Relatório Estatístico ---");
        System.out.println("Total de pacientes atendidos: " + atendidos.totalAtendidos());
        System.out.printf("Média de idade dos atendidos: %.2f anos\n", atendidos.mediaIdade());
    }

    private static String lerNomePaciente() {
        String nome;
        do {
            System.out.print("Nome do paciente: ");
            nome = scanner.nextLine().trim();
            if (!validarNome(nome)) {
                System.out.println("Nome inválido. Use apenas letras e espaços.");
                nome = "";
            }
        } while (nome.isEmpty());
        return nome;
    }

    private static int lerIdadePaciente() {
        int idade = 0;
        do {
            System.out.print("Idade do paciente: ");
            String entrada = scanner.nextLine().trim();
            try {
                idade = Integer.parseInt(entrada);
                if (idade <= 0) {
                    System.out.println("Idade deve ser maior que zero.");
                    idade = 0;
                }
            } catch (NumberFormatException e) {
                System.out.println("Idade inválida. Digite um número inteiro.");
            }
        } while (idade <= 0);
        return idade;
    }

    private static boolean lerUrgenciaPaciente() {
        String resposta;
        do {
            System.out.print("Paciente é urgente? (s/n): ");
            resposta = scanner.nextLine().trim().toLowerCase();
            if (resposta.equals("s")) {
                return true;
            } else if (resposta.equals("n")) {
                return false;
            } else {
                System.out.println("Resposta inválida. Digite 's' para sim ou 'n' para não.");
            }
        } while (true);
    }

    private static boolean validarNome(String nome) {
        return nome.matches("[A-Za-zÀ-ÿ ]+");
    }

    private static int lerInteiro(String prompt) {
        int num = -1;
        do {
            System.out.print(prompt);
            String entrada = scanner.nextLine();
            try {
                num = Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Digite um número inteiro.");
            }
        } while (num == -1);
        return num;
    }
}
